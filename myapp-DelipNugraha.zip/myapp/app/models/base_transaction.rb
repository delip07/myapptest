class BaseTransaction < ApplicationRecord
  belongs_to :transactionable, polymorphic: true

  validates :amount, numericality: { greater_than: 0 }
  validates :type, presence: true
end