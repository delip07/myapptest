class Stock < ApplicationRecord
  has_many :transactions, as: :transactionable

  validates :name, presence: true
  validates :price, numericality: { greater_than: 0 }
end