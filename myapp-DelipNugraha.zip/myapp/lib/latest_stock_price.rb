require 'net/http'
require 'json'

class LatestStockPrice
  BASE_URL = "https://latest-stock-price.p.rapidapi.com"
  API_KEY = "your_rapidapi_key" # Replace with your RapidAPI key

  def self.price(symbol)
    response = request("/stock/price/#{symbol}")
    JSON.parse(response.body)["price"]
  end

  def self.prices(symbols)
    symbols.join(",").tap do |symbol_str|
      response = request("/stock/prices/#{symbol_str}")
      JSON.parse(response.body)["prices"]
    end
  end

  def self.price_all
    response = request("/stock/prices/all")
    JSON.parse(response.body)
  end

  private

  def self.request(endpoint)
    uri = URI("#{BASE_URL}#{endpoint}")
    request = Net::HTTP::Get.new(uri)
    request['X-RapidAPI-Host'] = 'latest-stock-price.p.rapidapi.com'
    request['X-RapidAPI-Key'] = API_KEY

    Net::HTTP.start(uri.hostname, uri.port, use_ssl: uri.scheme == 'https') do |http|
      http.request(request)
    end
  end
end