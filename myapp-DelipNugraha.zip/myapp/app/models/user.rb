class User < ApplicationRecord
  has_many :transactions, as: :transactionable

  validates :name, presence: true
  validates :balance, numericality: { greater_than_or_equal_to: 0 }
end