class DepositTransaction < BaseTransaction
end